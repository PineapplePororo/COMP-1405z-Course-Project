# COMP-1405z-Course-Project

How to run the code:
'import search' and 'import searchdata' need to be below the line: crawler.crawl('http://people.scs.carleton.ca/~davidmckenney/fruits4/N-0.html')
That is because we have global JSON files in search.py and searchdata.py and it will give a JSON error if the crawl isn't run first.

Possible error during running:
KeyError: if this error shows up, rerun and it will work. 
